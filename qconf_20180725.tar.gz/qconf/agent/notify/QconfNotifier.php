<?php
/**
 *
 * @author wukezhan<wukezhan@gmail.com>
 * 2016-04-08 17:24
 *
 */

class QconfNotifier
{
    protected $_digest_dir;
    protected $_pid2Paths = [];
    protected $_pid2Names = [];
    protected $_wait_pids = [];
    protected $_timeout = 0;
    public function __construct($digest_dir='/tmp/pid', $timeout=600)
    {
        if(!is_dir($digest_dir)){
            if(!mkdir($digest_dir)){
                throw new Exception("digest dir {$digest_dir} not available");
            }
        }
        $this->_digest_dir = $digest_dir;
        $this->_timeout = $timeout;
    }

    protected static function _get_json_file($file)
    {
        return is_file($file)?json_decode(file_get_contents($file), 1): [];
    }

    public function get_meta_files()
    {
        $files = scandir($this->_digest_dir);
        $files = array_slice($files, 2);

        foreach($files as $file){
            if(!preg_match('/\.qconf$/', $file)){
                continue;
            }
            $file = $this->_digest_dir.DIRECTORY_SEPARATOR.$file;
            $meta = self::_get_json_file($file);
            $pid = $meta[0];
            $qconfPaths = $meta[1];
            $name = $meta[2];
            if(posix_getpgid($pid)){
                $this->_pid2Paths[$pid] = $qconfPaths;
                $this->_pid2Names[$pid] = $name;
            }else{
                unlink($file);
                echo "process {$meta[0]} not available, unlink pid file {$file}\n";
            }
        }
    }


    public function kill_and_wait()
    {
        if($this->_wait_pids){
            echo "start killing";
            $wait_pids = $this->_wait_pids;
            while($wait_pids){
                $n = 0;
                foreach($wait_pids as $idx => $pid){
                    if(!posix_kill($pid, SIGUSR1)){
                        echo ($n++?'':"\n")."`{$this->_pid2Names[$pid]}` has been killed\n";
                        unset($wait_pids[$idx]);
                    }
                }
                if($wait_pids){
                    echo '.';
                    sleep(1);

                    $this->_timeout--;
                    if(!$this->_timeout){
                        //send email
                        error_log(json_encode(['type'=>'reload timeout', 'pids' => $wait_pids])."\n", 3,'/tmp/pid/e.log');
                        //$this->send_alert($wait_pids);
                        break;
                    }
                }
            }
            $msg = (count($this->_wait_pids)-count($wait_pids))." processes has been killed gracefully\n";
            if($wait_pids){
                $msg .= count($wait_pids).' processes failed: '.implode(', ', $wait_pids)."\n\n";
            }
            echo '['.date('Y-m-d H:i:s').'] '.$msg;
        }else{
            echo "everything is up-to-date\n";
        }
    }

    public function process()
    {
        // 收集所有正在运行的常驻进程的元数据
        $this->get_meta_files();

        global $argv;
        echo '['.date('Y-m-d H:i:s').'] '."get argv ".json_encode($argv)."\r\n";
        foreach ($this->_pid2Paths as $pid => $paths) {
            if( in_array($argv[1],$paths)){
                $this->_wait_pids[] = $pid;
            }
        }
        // 终止待重启进程，并等待其终止状态返回
        $this->kill_and_wait();
    }
}

    // 独立运行模式
    $n = new QconfNotifier();
    $n->process();


