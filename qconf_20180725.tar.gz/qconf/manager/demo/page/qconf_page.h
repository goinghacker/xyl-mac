#ifndef QCONF_PAGE_H
#define QCONF_PAGE_H

#include <string>
#include <vector>

void generate(std::string path, std::string value, std::string idc, std::vector<std::string> idcs, std::vector<std::string> children, std::string target);

#endif
