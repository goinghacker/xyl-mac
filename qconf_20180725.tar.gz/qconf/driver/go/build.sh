#/bin/sh
pwd=`pwd`
if [ "$GOPATH" == "" ];then
    echo "GOPATH empty !"
    exit 1
else
    rm -rf $GOPATH/src/Qconf
    mkdir $GOPATH/src/Qconf
    cp  src/Qconf/qconf.go $GOPATH/src/Qconf/qconf.go
fi
#echo $GOPATH
go install Qconf
