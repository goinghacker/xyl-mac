package main
import (
        "fmt"
        "Qconf"
        )
func main(){
        var v string
        v,_= Qconf.GetModuleConfig("abc","main");
        fmt.Print(v);
        fmt.Print("-----------------------------\r\n")

        v,_= Qconf.GetCommonConfig("kafka-proxy");
        fmt.Print(v);
        fmt.Print("-----------------------------\r\n")

        v,_= Qconf.GetRedisConfig("crawler-redis");
        fmt.Print(v);
        fmt.Print("-----------------------------\r\n")

        v,_= Qconf.GetMysqlConfig("spiderDBMysqlConfigRw");
        fmt.Print(v);
        fmt.Print("-----------------------------\r\n")

        v,_= Qconf.GetHBaseConfig("hbaseTest");
        fmt.Print(v);
        fmt.Print("-----------------------------\r\n")

        v,_= Qconf.GetRabbitMqConfig("rabbitTest");
        fmt.Print(v);
        fmt.Print("-----------------------------\r\n")

}
