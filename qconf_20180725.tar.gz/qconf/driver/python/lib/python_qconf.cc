#include <Python.h>
#include "qconf.h"
static PyObject* QconfError;

#define QCONF_DRIVER_PYTHON_VERSION  "1.2.1"
#if PY_MAJOR_VERSION >= 3
    #define Pys_FromString(val) PyBytes_FromString(val)
#else
    #define Pys_FromString(val) PyString_FromString(val)
#endif

static int print_error_message(const int error_code)
{
    const char* message = NULL;
    switch (error_code)
    {
        case QCONF_ERR_OTHER :
            message = "Execute failure!";
            break;
        case QCONF_ERR_PARAM :
            message = "Error parameter!";
            break;
        case QCONF_ERR_MEM :
            message = "Failed to malloc memory!";
            break;
        case QCONF_ERR_TBL_SET :
            message = "Failed to set share memory";
            break;
        case QCONF_ERR_GET_HOST :
            message = "Failed to get zookeeper host!";
            break;
        case QCONF_ERR_GET_IDC :
            message = "Failed to get idc!";
            break;
        case QCONF_ERR_BUF_NOT_ENOUGH :
            message = "Buffer not enough!";
            break;
        case QCONF_ERR_DATA_TYPE :
            message = "Illegal data type!";
            break;
        case QCONF_ERR_DATA_FORMAT :
            message = "Illegal data format!";
            break;
        case QCONF_ERR_NOT_FOUND :
            message = "Failed to find the key on given idc!";
            break;
        case QCONF_ERR_OPEN_DUMP :
            message = "Failed to open dump file!";
            break;
        case QCONF_ERR_OPEN_TMP_DUMP :
            message = "Failed to open tmp dump file!";
            break;
        case QCONF_ERR_NOT_IN_DUMP :
            message = "Failed to find key in dump!";
            break;
        case QCONF_ERR_WRITE_DUMP :
            message = "Failed to write dump!";
            break;
        case QCONF_ERR_SAME_VALUE :
            message = "Same with the value in share memory!";
            break;
        case QCONF_ERR_OUT_OF_RANGE :
            message = "Configure item error : out of range!";
            break;
        case QCONF_ERR_NOT_NUMBER :
            message = "Configure item error : not number!";
            break;
        case QCONF_ERR_OTHRE_CHARACTER :
            message = "Configure item error : further characters exists!";
            break;
        case QCONF_ERR_INVALID_IP :
            message = "Configure item error : invalid ip!";
            break;
        case QCONF_ERR_INVALID_PORT :
            message = "Configure item error : invalid port!";
            break;
        case QCONF_ERR_NO_MESSAGE :
            message = "No message exist in message queue!";
            break;
        case QCONF_ERR_E2BIG :
            message = "Length of message in the queue is too large!";
            break;
        case QCONF_ERR_HOSTNAME :
            message = "Error hostname!";
            break;
        default :
            message = "Unknown error detected!";
            break;
    }
    PyErr_SetString(QconfError, message);
    return QCONF_OK;
}


static void Qconf_dealloc(void) 
{
    // Destroy the qconf env
    int ret = qconf_destroy();
    if (QCONF_OK != ret)
    {
        PyErr_SetString(QconfError, "destory qconf evn failed!");
        return;
    }
}

static int Qconf_init(void) 
{
    // Init the qconf env
    int ret = qconf_init();
    if (QCONF_OK != ret)
    {
        PyErr_SetString(QconfError, "inital qconf evn failed!");
        return QCONF_ERR_OTHER;
    }
    return QCONF_OK;
}

static PyObject* Qconf_get_mysql_config(PyObject *self, PyObject *args)
{
    char* mysqlName = NULL;
    char* idc = NULL;
    if (!PyArg_ParseTuple(args, "s", &mysqlName))
        return NULL;
    char path[100]="";
    sprintf(path,"/sudo/mysql/%s",mysqlName);
    char value[QCONF_CONF_BUF_MAX_LEN];
    int ret = qconf_get_conf(path, value, sizeof(value), idc);
    if (QCONF_OK != ret)
    {
        print_error_message(ret);
        return NULL;
    }

    return Pys_FromString(value);
}

static PyObject* Qconf_get_redis_config(PyObject *self, PyObject *args)
{
    char* redisName = NULL;
    char* idc = NULL;
    if (!PyArg_ParseTuple(args, "s", &redisName))
        return NULL;
    char path[100]="";
    sprintf(path,"/sudo/redis/%s",redisName);
    char value[QCONF_CONF_BUF_MAX_LEN];
    int ret = qconf_get_conf(path, value, sizeof(value), idc);
    if (QCONF_OK != ret)
    {
        print_error_message(ret);
        return NULL;
    }

    return Pys_FromString(value);
}
static PyObject* Qconf_get_hbase_config(PyObject *self, PyObject *args)
{
    char* hbaseName = NULL;
    char* idc = NULL;
    if (!PyArg_ParseTuple(args, "s", &hbaseName))
        return NULL;
    char path[100]="";
    sprintf(path,"/sudo/hbase/%s",hbaseName);
    char value[QCONF_CONF_BUF_MAX_LEN];
    int ret = qconf_get_conf(path, value, sizeof(value), idc);
    if (QCONF_OK != ret)
    {
        print_error_message(ret);
        return NULL;
    }

    return Pys_FromString(value);
}
static PyObject* Qconf_get_rabbitmq_config(PyObject *self, PyObject *args)
{
    char* rabbitmqName = NULL;
    char* idc = NULL;
    if (!PyArg_ParseTuple(args, "s", &rabbitmqName))
        return NULL;
    char path[100]="";
    sprintf(path,"/sudo/rabbitmq/%s",rabbitmqName);
    char value[QCONF_CONF_BUF_MAX_LEN];
    int ret = qconf_get_conf(path, value, sizeof(value), idc);
    if (QCONF_OK != ret)
    {
        print_error_message(ret);
        return NULL;
    }

    return Pys_FromString(value);
}

static PyObject* Qconf_get_common_config(PyObject *self, PyObject *args)
{
    char* configName = NULL;
    char* idc = NULL;
    if (!PyArg_ParseTuple(args, "s", &configName))
        return NULL;
    char path[100]="";
    if(configName[0] == '/'){
        sprintf(path,"/common%s",configName);
    }else{
        sprintf(path,"/common/%s",configName);
    }
    
    char value[QCONF_CONF_BUF_MAX_LEN];
    int ret = qconf_get_conf(path, value, sizeof(value), idc);
    if (QCONF_OK != ret)
    {
        print_error_message(ret);
        return NULL;
    }

    return Pys_FromString(value);
}

static PyObject* Qconf_get_module_config(PyObject *self, PyObject *args)
{
    char* module = NULL;
    char* configName = NULL;
    char* idc = NULL;
    if (!PyArg_ParseTuple(args, "ss", &module, &configName))
        return NULL;
    char path[100]="";
    if(configName[0] == '/'){
        sprintf(path,"/%s%s",module,configName);
    }else{
        sprintf(path,"/%s/%s",module,configName);
    }
    char value[QCONF_CONF_BUF_MAX_LEN];
    int ret = qconf_get_conf(path, value, sizeof(value), idc);
    if (QCONF_OK != ret)
    {
        print_error_message(ret);
        return NULL;
    }

    return Pys_FromString(value);
}

static PyObject* Qconf_version(PyObject *self)
{
    return Pys_FromString(QCONF_DRIVER_PYTHON_VERSION);
}


static PyMethodDef qconf_methods[] = {
    {"getMysqlConfig", (PyCFunction)Qconf_get_mysql_config, METH_VARARGS, "get mysql config"},
    {"getRedisConfig", (PyCFunction)Qconf_get_redis_config, METH_VARARGS, "get redis config"},
    {"getHBaseConfig", (PyCFunction)Qconf_get_hbase_config, METH_VARARGS, "get hbase config"},
    {"getRabbitMqConfig", (PyCFunction)Qconf_get_rabbitmq_config, METH_VARARGS, "get rabbitmq config"},
    {"getCommonConfig", (PyCFunction)Qconf_get_common_config, METH_VARARGS, "get common config"},
    {"getModuleConfig", (PyCFunction)Qconf_get_module_config, METH_VARARGS, "get module config"},
    {"version", (PyCFunction)Qconf_version, METH_NOARGS, "qconf version"},
    {NULL, NULL, 0, NULL}
};

#if PY_MAJOR_VERSION >= 3
static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,
    "RongQconf",     /* m_name */
    "Python extension of Qconf",  /* m_doc */
    -1,                  /* m_size */
    qconf_methods,    /* m_methods */
    NULL,                /* m_reload */
    NULL,                /* m_traverse */
    NULL,                /* m_clear */
    NULL,                /* m_free */
};
#endif

#if PY_MAJOR_VERSION >= 3
    #define MOD_INIT(name) PyMODINIT_FUNC PyInit_##name(void)
#else
    #define MOD_INIT(name) PyMODINIT_FUNC init##name(void)
#endif


MOD_INIT(RongQconf)
{
    PyObject *m;
#if PY_MAJOR_VERSION >= 3
    m = PyModule_Create(&moduledef);
#else
    m = Py_InitModule3("RongQconf", qconf_methods, "Python extension of Qconf");
#endif
    if (NULL == m)
#if PY_MAJOR_VERSION >= 3
        return NULL;
#else
        return;
#endif
    QconfError = PyErr_NewException("RongQconf.Error", NULL, NULL);
    Py_INCREF(QconfError);
    PyModule_AddObject(m, "Error", QconfError);

    int ret = Qconf_init();
    if (QCONF_ERR_OTHER == ret)
#if PY_MAJOR_VERSION >= 3
        return NULL;
#else
        return;
#endif
    ret = Py_AtExit(Qconf_dealloc);
    if (-1 == ret)
    {
        Qconf_dealloc();
#if PY_MAJOR_VERSION >= 3
        return NULL;
#else
        return;
#endif
    }
#if PY_MAJOR_VERSION >= 3
    return m;
#else
    return;
#endif
}
