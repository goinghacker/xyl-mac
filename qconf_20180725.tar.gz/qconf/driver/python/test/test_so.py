#!/usr/bin/python
import RongQconf 

#*********************Basic Usage*******************************
try:
    #get common config
    value = RongQconf.getCommonConfig("kafka_proxy")
    if value is "":
        print "empty string"
    print "value : " + value
    
    #get module config
    value = RongQconf.getModuleConfig("main","abc")
    if value is "":
        print "empty string"
    print "value : " + value

    #get mysql config
    value = RongQconf.getMysqlConfig("spiderMysqlConfigRw")
    if value is "":
        print "empty string"
    print "value : " + value

    #get redis config
    value = RongQconf.getRedisConfig("crawler-redis")
    if value is "":
        print "empty string"
    print "value : " + value

    #get hbase config
    value = RongQconf.getHBaseConfig("hbaseConfig")
    if value is "":
        print "empty string"
    print "value : " + value

    #get rabbitmq config
    value = RongQconf.getRabbitMqConfig("rabbitTest")
    if value is "":
        print "empty string"
    print "value : " + value

    # #get mysql config
    # value = RongQconf.getMysqlConfig("spiderMysqlConfigRw")
    # if value is "":
    #     print "empty string"
    # print "value : " + value

    

except RongQconf.Error, Argument:
    print "error happend in Basic Usage! ", Argument