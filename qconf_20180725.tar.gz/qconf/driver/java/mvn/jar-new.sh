#/bin/sh
# echo `pwd`
mkdir tmp
cp ../qconf_jar/qconf-client-1.0.0.jar .
cp target/qconf-0.1.jar .
cd tmp
jar -xf ../qconf-0.1.jar
jar -xf ../qconf-client-1.0.0.jar
jar -cvf qconf.jar *
cd ..
mv tmp/qconf.jar .
rm -rf tmp
rm -rf qconf-client-1.0.0.jar
rm -rf qconf-0.1.jar
