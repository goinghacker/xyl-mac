package org.rong360.qconf;

import net.qihoo.qconf.Qconf;
import net.qihoo.qconf.QconfException;
public class RongOpConfig{

	public String getMysqlConfig(String dbConfName){
		if(dbConfName.equals("")){
			// log.error("no dbConfName passed");
			return "";
		}
		String path = "/sudo/mysql/"+dbConfName;
		try{
            String value = Qconf.getConf(path);
            return value;
        }
        catch(QconfException e){
            // log.error(e.toString());
            return "";
        }
	}

	public String getRedisConfig(String redisConfName){
		if(redisConfName.equals("")){
			// log.error("no dbConfName passed");
			return "";
		}
		String path = "/sudo/redis/"+redisConfName;
		try{
            String value = Qconf.getConf(path);
            return value;
        }
        catch(QconfException e){
            // log.error(e.toString());
            return "";
        }
	}
	public String getHBaseConfig(String hbaseConfName){
		if(hbaseConfName.equals("")){
			// log.error("no dbConfName passed");
			return "";
		}
		String path = "/sudo/hbase/"+hbaseConfName;
		try{
            String value = Qconf.getConf(path);
            return value;
        }
        catch(QconfException e){
            // log.error(e.toString());
            return "";
        }
	}
	public String getRabbitMqConfig(String rabbitConfName){
		if(rabbitConfName.equals("")){
			// log.error("no dbConfName passed");
			return "";
		}
		String path = "/sudo/rabbitmq/"+rabbitConfName;
		try{
            String value = Qconf.getConf(path);
            return value;
        }
        catch(QconfException e){
            // log.error(e.toString());
            return "";
        }
	}
}