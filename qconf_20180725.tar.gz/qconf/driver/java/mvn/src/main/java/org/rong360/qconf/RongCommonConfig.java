package org.rong360.qconf;

import net.qihoo.qconf.Qconf;
import net.qihoo.qconf.QconfException;
public class RongCommonConfig{

	public String getConfig(String conf){
		if(conf.equals("")){
			// log.error("no dbConfName passed");
			return "";
		}
		if(!conf.startsWith("/")){
			conf = "/"+conf;
		}
		String path = "/common"+conf;
		try{
            String value = Qconf.getConf(path);
            return value;
        }
        catch(QconfException e){
            // log.error(e.toString());
            return "";
        }
	}
}