package org.rong360.qconf;

import net.qihoo.qconf.Qconf;
import net.qihoo.qconf.QconfException;
public class RongModuleConfig{

	public String getConfig(String moduleName, String conf){
		if(moduleName.equals("") || conf.equals("")){
			// log.error("no dbConfName passed");
			return "";
		}
		if(!conf.startsWith("/")){
			conf = "/"+conf;
		}
		String path = "/"+moduleName+conf;
		try{
            String value = Qconf.getConf(path);
            return value;
        }
        catch(QconfException e){
            // log.error(e.toString());
            return "";
        }
	}
}