import org.rong360.qconf.*;
import java.io.*;
public class test{
	public static void main(String[] args) {
		RongOpConfig config = new RongOpConfig();
		//获取mysql配置
		System.out.println(config.getMysqlConfig("messageDBMysqlConfigRw"));
		//获取redis配置
		System.out.println(config.getRedisConfig("redisMain"));
		//获取hbase配置
		System.out.println(config.getHBaseConfig("hbaseTest"));
		//获取hbase配置
		System.out.println(config.getRabbitMqConfig("rabbitTest"));
		//获取业务线业务配置
		RongModuleConfig configM = new RongModuleConfig();
		System.out.println(configM.getConfig("main","/abc"));
		//获取common配置
		RongCommonConfig configC = new RongCommonConfig();
		System.out.println(configC.getConfig("/kafka_proxy"));
	}
}