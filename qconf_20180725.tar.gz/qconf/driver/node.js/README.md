assume you install qconf at /usr/local/qconf
you need two steps to generate c++ addon for node.js
node-gyp configure
node-gyp build

Thanks to @demohi and following is his implementation.
https://github.com/bluedapp/node-qconf


